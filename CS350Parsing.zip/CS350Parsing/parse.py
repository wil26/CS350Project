import os
import random

if os.path.exists('output.txt'):
    os.remove('output.txt')
with open('names.txt', 'r') as source:
    data = [(random.random(), line) for line in source]
data.sort()
with open('output.txt', 'w') as target:
    for _, line in data:
        target.write(line.strip() + ':' + str(random.randint(0, 1000)) + '\n')

'''
# old code without randomizing lines
file_write_obj = open('source.txt', 'a')
with open("names.txt", 'r') as file_obj:
    # print(file_obj)
    line = file_obj.readline()
    count = 1
    while line:
        print(line)
        file_write_obj.write(line.strip() + ':' + str(randint(0, 1000)) + '\n')
        line = file_obj.readline()
        count += 1
    file_obj.close()
'''
